Hibernate L2 Cache Configuration Example
----------------------------------------

This folder contains example-hibernate-L2-cache.xml file that demonstrates
how to configure Hibernate to use Apache Ignite cache as an L2 cache provider.

This file is also used in Hibernate example located in org.apache.ignite.examples.datagrid.hibernate
package.
