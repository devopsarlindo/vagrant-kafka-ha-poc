Servlet Configuration Example
-----------------------------

This folder contains web.xml file that demonstrates how to configure any servlet container
to start a Apache Ignite node inside a Web application.

For more information on available configuration properties, etc. refer to our documentation:
http://apacheignite.readme.io/docs/web-session-clustering
